class TestResult {
  final String id;
  final DateTime date;
  final double download;
  final double upload;
  final int ping;
  final String ispName;

  TestResult({
    required this.id,
    required this.date,
    required this.download,
    required this.upload,
    required this.ping,
    required this.ispName,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'date': date.toIso8601String(),
        'download': download,
        'upload': upload,
        'ping': ping,
        'ispName': ispName,
      };

  factory TestResult.fromJson(Map<String, dynamic> json) => TestResult(
        id: json['id'],
        date: DateTime.parse(json['date']),
        download: (json['download'] as num).toDouble(),
        upload: (json['upload'] as num).toDouble(),
        ping: json['ping'] as int,
        ispName: json['ispName'] ?? 'غير معروف',
      );
}
