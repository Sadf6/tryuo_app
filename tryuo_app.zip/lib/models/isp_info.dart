import 'package:flutter/material.dart';

class IspInfo {
  final String name;
  final String ip;
  final IconData icon;
  final Color accentColor;

  IspInfo({
    required this.name,
    required this.ip,
    required this.icon,
    required this.accentColor,
  });
}
