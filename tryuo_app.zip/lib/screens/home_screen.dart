import 'dart:async';
import 'package:flutter/material.dart';
import '../models/isp_info.dart';
import '../models/test_result.dart';
import '../services/isp_service.dart';
import '../services/speed_test_service.dart';
import '../services/history_repository.dart';
import '../widgets/gauge_painter.dart';
import 'history_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final SpeedTestService _speedTestService = SpeedTestService();
  StreamSubscription<double>? _speedSubscription;

  bool _isTesting = false;
  double _currentSpeed = 0.0;
  double _downloadSpeed = 0.0;
  double _uploadSpeed = 0.0;
  int _ping = 0;
  String _testPhase = 'اضغط للبدء';

  IspInfo _ispInfo = IspInfo(
    name: 'جاري التعرف على الشبكة...',
    ip: '0.0.0.0',
    icon: Icons.sync,
    accentColor: const Color(0xFF00B4D8),
  );

  @override
  void initState() {
    super.initState();
    _loadIspData();
  }

  void _loadIspData() async {
    final info = await IspService.fetchIspDetails();
    setState(() {
      _ispInfo = info;
    });
  }

  void _startFullTest() async {
    if (_isTesting) return;

    setState(() {
      _isTesting = true;
      _currentSpeed = 0.0;
      _downloadSpeed = 0.0;
      _uploadSpeed = 0.0;
      _ping = 0;
      _testPhase = 'جاري قياس الـ Ping...';
    });

    final pingResults = await _speedTestService.measurePingAndJitter();
    setState(() {
      _ping = pingResults['ping'] ?? 0;
      _testPhase = 'جاري قياس التنزيل...';
    });

    _speedSubscription = _speedTestService.measureDownloadSpeed().listen(
      (speed) {
        setState(() {
          _downloadSpeed = speed;
          _currentSpeed = speed;
        });
      },
      onDone: () {
        setState(() {
          _testPhase = 'جاري قياس الرفع...';
        });

        _speedSubscription = _speedTestService.measureUploadSpeed().listen(
          (uploadSpeed) {
            setState(() {
              _uploadSpeed = uploadSpeed;
              _currentSpeed = uploadSpeed;
            });
          },
          onDone: () async {
            setState(() {
              _isTesting = false;
              _testPhase = 'اكتمل الفحص';
            });

            await HistoryRepository.saveResult(
              TestResult(
                id: DateTime.now().millisecondsSinceEpoch.toString(),
                date: DateTime.now(),
                download: _downloadSpeed,
                upload: _uploadSpeed,
                ping: _ping,
                ispName: _ispInfo.name,
              ),
            );
          },
        );
      },
    );
  }

  @override
  void dispose() {
    _speedSubscription?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    double progressRatio = (_currentSpeed / 100.0).clamp(0.0, 1.0);

    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 15.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  IconButton(
                    icon: const Icon(Icons.history_rounded, color: Color(0xFFD4AF37), size: 28),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => const HistoryScreen()),
                      );
                    },
                  ),
                  const Text(
                    'TRYUO',
                    style: TextStyle(
                      fontSize: 32,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 4,
                      color: Color(0xFFD4AF37),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.refresh_rounded, color: Color(0xFF00B4D8)),
                    onPressed: _loadIspData,
                  ),
                ],
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                decoration: BoxDecoration(
                  color: const Color(0xFF1E5162).withOpacity(0.3),
                  borderRadius: BorderRadius.circular(15),
                  border: Border.all(color: _ispInfo.accentColor.withOpacity(0.5)),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(_ispInfo.icon, color: _ispInfo.accentColor, size: 20),
                    const SizedBox(width: 10),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          _ispInfo.name,
                          style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.bold),
                        ),
                        Text(
                          'IP: ${_ispInfo.ip}',
                          style: const TextStyle(color: Colors.white38, fontSize: 10),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              GestureDetector(
                onTap: _startFullTest,
                child: SizedBox(
                  width: 260,
                  height: 260,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      CustomPaint(
                        size: const Size(260, 260),
                        painter: GaugePainter(progress: progressRatio),
                      ),
                      Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            _currentSpeed.toStringAsFixed(1),
                            style: const TextStyle(
                              fontSize: 52,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                              height: 1.0,
                            ),
                          ),
                          const SizedBox(height: 6),
                          const Text(
                            'Mbps',
                            style: TextStyle(
                              color: Color(0xFF00B4D8),
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          const SizedBox(height: 14),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                            decoration: BoxDecoration(
                              color: _isTesting
                                  ? const Color(0xFF00B4D8).withOpacity(0.2)
                                  : const Color(0xFFD4AF37).withOpacity(0.2),
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(
                                color: _isTesting ? const Color(0xFF00B4D8) : const Color(0xFFD4AF37),
                              ),
                            ),
                            child: Text(
                              _testPhase,
                              style: TextStyle(
                                color: _isTesting ? const Color(0xFF00B4D8) : const Color(0xFFD4AF37),
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _buildMetricCard('تنزيل', _downloadSpeed.toStringAsFixed(1), 'Mbps', Icons.download, const Color(0xFF00B4D8)),
                  _buildMetricCard('رفع', _uploadSpeed.toStringAsFixed(1), 'Mbps', Icons.upload, const Color(0xFFD4AF37)),
                  _buildMetricCard('Ping', '$_ping', 'ms', Icons.speed, Colors.white70),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMetricCard(String title, String value, String unit, IconData icon, Color accentColor) {
    return Container(
      width: 95,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.04),
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: accentColor.withOpacity(0.3)),
      ),
      child: Column(
        children: [
          Icon(icon, color: accentColor, size: 20),
          const SizedBox(height: 6),
          Text(title, style: const TextStyle(color: Colors.white60, fontSize: 12)),
          const SizedBox(height: 4),
          Text(
            value,
            style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
          ),
          Text(unit, style: const TextStyle(color: Colors.white38, fontSize: 10)),
        ],
      ),
    );
  }
}
