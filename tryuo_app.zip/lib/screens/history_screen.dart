import 'package:flutter/material.dart';
import '../models/test_result.dart';
import '../services/history_repository.dart';
import '../services/export_service.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  List<TestResult> _history = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadHistory();
  }

  void _loadHistory() async {
    final list = await HistoryRepository.getHistory();
    setState(() {
      _history = list;
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0B192C),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0B192C),
        elevation: 0,
        title: const Text(
          'سجل الفحوصات',
          style: TextStyle(color: Color(0xFFD4AF37), fontWeight: FontWeight.bold),
        ),
        actions: [
          if (_history.isNotEmpty)
            IconButton(
              icon: const Icon(Icons.share_rounded, color: Color(0xFF00B4D8)),
              tooltip: 'تصدير CSV',
              onPressed: () => ExportService.exportToCSV(_history),
            ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator(color: Color(0xFF00B4D8)))
          : _history.isEmpty
              ? const Center(
                  child: Text(
                    'لا يوجد سجل فحوصات سابق',
                    style: TextStyle(color: Colors.white54, fontSize: 16),
                  ),
                )
              : Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0),
                  child: Column(
                    children: [
                      _buildSummaryCard(),
                      const SizedBox(height: 15),
                      Expanded(
                        child: ListView.builder(
                          itemCount: _history.length,
                          itemBuilder: (context, index) {
                            final item = _history[index];
                            return _buildHistoryItemCard(item);
                          },
                        ),
                      ),
                    ],
                  ),
                ),
    );
  }

  Widget _buildSummaryCard() {
    final maxDownload = _history.map((e) => e.download).reduce((a, b) => a > b ? a : b);
    final avgDownload = _history.map((e) => e.download).reduce((a, b) => a + b) / _history.length;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF1E5162).withOpacity(0.3),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFD4AF37).withOpacity(0.4)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _buildSummaryItem('أعلى تنزيل', '${maxDownload.toStringAsFixed(1)} Mbps', Icons.bolt, const Color(0xFFD4AF37)),
          Container(width: 1, height: 35, color: Colors.white12),
          _buildSummaryItem('المتوسط', '${avgDownload.toStringAsFixed(1)} Mbps', Icons.speed, const Color(0xFF00B4D8)),
          Container(width: 1, height: 35, color: Colors.white12),
          _buildSummaryItem('عدد الفحوصات', '${_history.length}', Icons.history, Colors.white),
        ],
      ),
    );
  }

  Widget _buildSummaryItem(String label, String value, IconData icon, Color color) {
    return Column(
      children: [
        Icon(icon, color: color, size: 18),
        const SizedBox(height: 4),
        Text(label, style: const TextStyle(color: Colors.white54, fontSize: 10)),
        const SizedBox(height: 2),
        Text(value, style: TextStyle(color: color, fontSize: 14, fontWeight: FontWeight.bold)),
      ],
    );
  }

  Widget _buildHistoryItemCard(TestResult item) {
    final dateStr = "${item.date.day}/${item.date.month}/${item.date.year} - ${item.date.hour}:${item.date.minute.toString().padLeft(2, '0')}";

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.04),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white.withOpacity(0.08)),
      ),
      child: Row(
        children: [
          CircleAvatar(
            backgroundColor: const Color(0xFF1E5162).withOpacity(0.5),
            radius: 20,
            child: const Icon(Icons.wifi, color: Color(0xFF00B4D8), size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  item.ispName,
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13),
                ),
                const SizedBox(height: 3),
                Text(
                  dateStr,
                  style: const TextStyle(color: Colors.white38, fontSize: 11),
                ),
              ],
            ),
          ),
          Row(
            children: [
              _buildValueBadge(Icons.download, item.download.toStringAsFixed(1), const Color(0xFF00B4D8)),
              const SizedBox(width: 8),
              _buildValueBadge(Icons.upload, item.upload.toStringAsFixed(1), const Color(0xFFD4AF37)),
              const SizedBox(width: 8),
              _buildValueBadge(Icons.speed, '${item.ping}ms', Colors.white70),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildValueBadge(IconData icon, String value, Color color) {
    return Column(
      children: [
        Icon(icon, color: color, size: 14),
        const SizedBox(height: 2),
        Text(
          value,
          style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w600),
        ),
      ],
    );
  }
}
