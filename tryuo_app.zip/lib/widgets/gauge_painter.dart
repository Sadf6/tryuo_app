import 'dart:math' as math;
import 'package:flutter/material.dart';

class GaugePainter extends CustomPainter {
  final double progress;

  GaugePainter({required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = (size.width / 2) - 16;

    const startAngle = 135 * (math.pi / 180);
    const totalSweepAngle = 270 * (math.pi / 180);

    final trackPaint = Paint()
      ..color = const Color(0xFF1E5162).withOpacity(0.25)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 14.0
      ..strokeCap = StrokeCap.round;

    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius),
      startAngle,
      totalSweepAngle,
      false,
      trackPaint,
    );

    if (progress > 0) {
      final activeSweepAngle = totalSweepAngle * progress.clamp(0.0, 1.0);

      final progressPaint = Paint()
        ..shader = const SweepGradient(
          colors: [Color(0xFF1E5162), Color(0xFF00B4D8), Color(0xFFD4AF37)],
          stops: [0.0, 0.65, 1.0],
          transform: GradientRotation(startAngle),
        ).createShader(Rect.fromCircle(center: center, radius: radius))
        ..style = PaintingStyle.stroke
        ..strokeWidth = 14.0
        ..strokeCap = StrokeCap.round;

      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius),
        startAngle,
        activeSweepAngle,
        false,
        progressPaint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant GaugePainter oldDelegate) {
    return oldDelegate.progress != progress;
  }
}
