import 'dart:async';
import 'dart:io';

class SpeedTestService {
  final String _downloadUrl = 'https://speed.cloudflare.com/__down?bytes=25000000'\;
  final String _pingUrl = 'https://speed.cloudflare.com/__down?bytes=0'\;
  final String _uploadUrl = 'https://speed.cloudflare.com/__up'\;

  Future<Map<String, int>> measurePingAndJitter() async {
    final client = HttpClient();
    List<int> pings = [];

    try {
      for (int i = 0; i < 5; i++) {
        final stopwatch = Stopwatch()..start();
        final request = await client.getUrl(Uri.parse(_pingUrl));
        final response = await request.close();
        await response.drain();
        stopwatch.stop();

        pings.add(stopwatch.elapsedMilliseconds);
        await Future.delayed(const Duration(milliseconds: 80));
      }

      if (pings.isEmpty) return {'ping': 0, 'jitter': 0};

      int avgPing = (pings.reduce((a, b) => a + b) / pings.length).round();

      double jitterSum = 0;
      for (int i = 0; i < pings.length - 1; i++) {
        jitterSum += (pings[i] - pings[i + 1]).abs();
      }
      int jitter = pings.length > 1 ? (jitterSum / (pings.length - 1)).round() : 0;

      return {'ping': avgPing, 'jitter': jitter};
    } catch (e) {
      return {'ping': 0, 'jitter': 0};
    } finally {
      client.close();
    }
  }

  Stream<double> measureDownloadSpeed() async* {
    final client = HttpClient();
    final stopwatch = Stopwatch();
    int totalBytes = 0;
    double smoothedSpeed = 0.0;
    const double alpha = 0.25;

    try {
      final request = await client.getUrl(Uri.parse(_downloadUrl));
      final response = await request.close();

      stopwatch.start();

      await for (List<int> chunk in response) {
        totalBytes += chunk.length;
        final double elapsedSeconds = stopwatch.elapsedMicroseconds / 1000000.0;

        if (elapsedSeconds > 0.05) {
          final double instantSpeed = (totalBytes * 8) / (elapsedSeconds * 1000000.0);
          smoothedSpeed = (smoothedSpeed == 0.0)
              ? instantSpeed
              : (alpha * instantSpeed) + ((1 - alpha) * smoothedSpeed);

          yield smoothedSpeed;
        }
      }
      stopwatch.stop();
    } catch (e) {
      yield 0.0;
    } finally {
      client.close();
    }
  }

  Stream<double> measureUploadSpeed() async* {
    final client = HttpClient();
    final stopwatch = Stopwatch();

    final int payloadSize = 10 * 1024 * 1024;
    final List<int> dummyChunk = List.filled(64 * 1024, 65);
    int uploadedBytes = 0;
    double smoothedSpeed = 0.0;
    const double alpha = 0.25;

    try {
      final request = await client.postUrl(Uri.parse(_uploadUrl));
      request.contentLength = payloadSize;

      stopwatch.start();

      int chunksCount = payloadSize ~/ dummyChunk.length;
      for (int i = 0; i < chunksCount; i++) {
        request.add(dummyChunk);
        uploadedBytes += dummyChunk.length;

        final double elapsedSeconds = stopwatch.elapsedMicroseconds / 1000000.0;

        if (elapsedSeconds > 0.05) {
          final double instantSpeed = (uploadedBytes * 8) / (elapsedSeconds * 1000000.0);
          smoothedSpeed = (smoothedSpeed == 0.0)
              ? instantSpeed
              : (alpha * instantSpeed) + ((1 - alpha) * smoothedSpeed);

          yield smoothedSpeed;
        }
      }

      final response = await request.close();
      await response.drain();
      stopwatch.stop();
    } catch (e) {
      yield 0.0;
    } finally {
      client.close();
    }
  }
}
