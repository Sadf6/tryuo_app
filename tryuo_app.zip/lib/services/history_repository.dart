import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/test_result.dart';

class HistoryRepository {
  static const String _key = 'tryuo_test_history';

  static Future<void> saveResult(TestResult result) async {
    final prefs = await SharedPreferences.getInstance();
    final List<TestResult> currentHistory = await getHistory();
    currentHistory.insert(0, result);

    final String encoded = json.encode(
      currentHistory.map((item) => item.toJson()).toList(),
    );
    await prefs.setString(_key, encoded);
  }

  static Future<List<TestResult>> getHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final String? rawData = prefs.getString(_key);
    if (rawData == null) return [];

    final List<dynamic> decoded = json.decode(rawData);
    return decoded.map((item) => TestResult.fromJson(item)).toList();
  }

  static Future<void> clearHistory() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_key);
  }
}
