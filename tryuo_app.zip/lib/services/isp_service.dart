import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../models/isp_info.dart';

class IspService {
  static Future<IspInfo> fetchIspDetails() async {
    try {
      final response = await http
          .get(Uri.parse('https://ipapi.co/json/'))
          .timeout(const Duration(seconds: 5));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final String asn = (data['asn'] ?? '').toString();
        final String org = (data['org'] ?? '').toString();
        final String ip = (data['ip'] ?? '0.0.0.0').toString();

        if (asn.contains('14593') || org.contains('SpaceX') || org.contains('Starlink')) {
          return IspInfo(
            name: 'Starlink',
            ip: ip,
            icon: Icons.satellite_alt_rounded,
            accentColor: Colors.purpleAccent,
          );
        } else if (asn.contains('48332') || org.contains('Asiacell')) {
          return IspInfo(
            name: 'آسيا سيل (Asiacell)',
            ip: ip,
            icon: Icons.cell_tower_rounded,
            accentColor: const Color(0xFFE31E24),
          );
        } else if (asn.contains('50422') || org.contains('Zain')) {
          return IspInfo(
            name: 'زين العراق (Zain)',
            ip: ip,
            icon: Icons.signal_cellular_alt_rounded,
            accentColor: const Color(0xFF00B4D8),
          );
        } else if (asn.contains('15897') || org.contains('Earthlink')) {
          return IspInfo(
            name: 'إيرثلنك (Earthlink)',
            ip: ip,
            icon: Icons.wifi_rounded,
            accentColor: const Color(0xFFD4AF37),
          );
        } else if (asn.contains('51101') || org.contains('Korek')) {
          return IspInfo(
            name: 'كورك (Korek)',
            ip: ip,
            icon: Icons.cell_tower_rounded,
            accentColor: Colors.orangeAccent,
          );
        } else {
          return IspInfo(
            name: org.isNotEmpty ? org : 'مزود غير معروف',
            ip: ip,
            icon: Icons.wifi_find_rounded,
            accentColor: Colors.white70,
          );
        }
      }
    } catch (_) {}

    return IspInfo(
      name: 'تعذر التحديد (أو VPN مفعل)',
      ip: '--.--.--.--',
      icon: Icons.wifi_off_rounded,
      accentColor: Colors.grey,
    );
  }
}
