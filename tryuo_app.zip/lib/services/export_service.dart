import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../models/test_result.dart';

class ExportService {
  static Future<void> exportToCSV(List<TestResult> history) async {
    if (history.isEmpty) return;

    StringBuffer csvData = StringBuffer();
    csvData.writeln("ID,Date,Time,ISP,Download (Mbps),Upload (Mbps),Ping (ms)");

    for (var item in history) {
      final formattedDate = "${item.date.year}-${item.date.month.toString().padLeft(2, '0')}-${item.date.day.toString().padLeft(2, '0')}";
      final formattedTime = "${item.date.hour.toString().padLeft(2, '0')}:${item.date.minute.toString().padLeft(2, '0')}";

      csvData.writeln(
        '"${item.id}","$formattedDate","$formattedTime","${item.ispName}",${item.download.toStringAsFixed(2)},${item.upload.toStringAsFixed(2)},${item.ping}',
      );
    }

    final directory = await getTemporaryDirectory();
    final filePath = "${directory.path}/TRYUO_Speed_History.csv";
    final file = File(filePath);
    await file.writeAsString(csvData.toString());

    await Share.shareXFiles([XFile(filePath)], text: 'سجل فحوصات سرعة شبكة TRYUO');
  }
}
